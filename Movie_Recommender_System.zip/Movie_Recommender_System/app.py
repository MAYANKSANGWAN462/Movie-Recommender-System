from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import time

# --- Initialize Flask app ---
app = Flask(__name__)

# --- Load data and similarity matrix ---
movies = pickle.load(open('movies.pkl', 'rb'))
similarity = pickle.load(open('similarity.pkl', 'rb'))

# --- Your TMDB API key ---
API_KEY = "dd9d0c38bee5a657640627c4d9265631"

# --- Setup a persistent TMDB session ---
session = requests.Session()
retry = Retry(connect=3, backoff_factor=1, status_forcelist=[502, 503, 504])
adapter = HTTPAdapter(max_retries=retry)
session.mount("https://", adapter)

# --- Function to fetch movie poster from TMDB API ---
def fetch_poster(movie_id):
    url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={API_KEY}&language=en-US"
    response = session.get(url, timeout=5)
    data = response.json()
    poster_path = data.get("poster_path")
    if poster_path:
        return "https://image.tmdb.org/t/p/w500/" + poster_path
    else:
        return "https://via.placeholder.com/200x300?text=No+Image"

# --- Home route ---
@app.route('/')
def home():
    movie_titles = sorted(movies['title'].values)
    return render_template('index.html', movie_list=movie_titles, movie_name=None)

# --- Recommendation route ---
@app.route('/recommend', methods=['POST'])
def recommend():
    movie_name = request.form['movie_name'].strip().lower()
    movie_titles = movies['title'].str.lower()

    # check if movie exists
    if movie_name not in movie_titles.values:
        return render_template('index.html',
                               movie_list=sorted(movies['title'].values),
                               recommendation=["Movie not found."])

    # find movie index
    index = movie_titles[movie_titles == movie_name].index[0]

    # get similarity scores
    distances = similarity[index]
    movie_list = sorted(list(enumerate(distances)), reverse=True, key=lambda x: x[1])[1:6]

    # store recommendations and posters
    recommended_movies = []
    recommended_movies_posters = []

    for i in movie_list:
        movie_id = movies.iloc[i[0]].movie_id
        time.sleep(0.2)  # small delay to avoid rate-limit
        recommended_movies.append(movies.iloc[i[0]].title)
        recommended_movies_posters.append(fetch_poster(movie_id))

    combined = zip(recommended_movies, recommended_movies_posters)

    return render_template(
    'index.html',
    movie_list=sorted(movies['title'].values),
    combined=combined,
    movie_name=movies.iloc[index].title
)

# --- Run the Flask app ---
if __name__ == '__main__':
    app.run(debug=True)
